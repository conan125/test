{-# LANGUAGE OverloadedStrings, QuasiQuotes, TemplateHaskell, TypeFamilies #-}
import Yesod
import Data.Aeson

data App = App

mkYesod "App" [parseRoutes|
/users UserR GET POST
/users/#UserId UserItemIdR GET PUT DELETE
|]

instance Yesod App

data User = User { userId :: Int, userName :: String }
    deriving (Eq, Show)

instance ToJSON User where
    toJSON (User uid name) = object ["id" .= uid, "name" .= name]

instance FromJSON User where
    parseJSON (Object o) = User <$> o .: "id" <*> o .: "name"
    parseJSON _ = fail "Expected an object for User"

type UserId = Int

getUsers :: Handler Value
getUsers = returnJson [ User 1 "Alice", User 2 "Bob" ]

postUsers :: Handler Value
postUsers = do
    user <- requireJsonBody :: Handler User
    returnJson user

getUserItemR :: UserId -> Handler Value
getUserItemR uid = returnJson (User uid "Alice")

putUserItemR :: UserId -> Handler Value
putUserItemR uid = do
    user <- requireJsonBody :: Handler User
    returnJson user

deleteUserItemR :: UserId -> Handler Value
deleteUserItemR uid = returnJson $ object ["status" .= ("deleted" :: String)]

main :: IO ()
main = warp 4000 App
