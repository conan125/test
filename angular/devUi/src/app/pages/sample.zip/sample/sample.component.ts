import { ModalService } from './modal.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.css'],
})
export class SampleComponent implements OnInit {
  constructor(public modalService: ModalService) {}
  ngOnInit(): void {}
  // 图片点击
  imageClick() {
    this.modalService.modalState.emit(' in');
  }
  state = {
    modal1: false,
  };
  onClose(key: string | number) {
    this.state[key] = false;
  }
  showModal(key: string) {
    this.state[key] = true;
  }
  test(s) {
    console.log(s);
  }
}
